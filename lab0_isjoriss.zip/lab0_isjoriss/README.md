Isabella Jorissen
Lab 0 
1.31.14
Math 382 


### Bubble Sort 

Lab 0 consists of a .scala file called bubble.scala that performs bubble sort on  a list of integers given to the program via command line.  